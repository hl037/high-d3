// Main Vue plugin and exports
import type { App, Plugin } from 'vue';
import { getHd3GlobalBus } from '../core/bus/Hd3Bus';

// Symbols for provide/inject
export const Hd3ChartSymbol = Symbol('Hd3Chart');
export const Hd3BusSymbol = Symbol('Hd3Bus');
export const Hd3InteractionAreaSymbol = Symbol('Hd3InteractionArea');

// Plugin definition
export const Hd3Plugin: Plugin = {
  install(app: App) {
    const bus = getHd3GlobalBus();
    app.provide(Hd3BusSymbol, bus);
  }
};

// Re-export core types needed by Vue components
export * from '../core/types';
export { Hd3Series } from '../core/series/Hd3Series';
export { Hd3AxisDomain } from '../core/axis/Hd3AxisDomain';
export { Hd3Toolbox } from '../core/interaction/Hd3Toolbox';
export * from '../core/interaction/tools/Hd3PanTool';
export * from '../core/interaction/tools/Hd3ZoomTool';
export * from '../core/interaction/tools/Hd3ZoomToSelectionTool';
export * from '../core/interaction/tools/Hd3ResetTool';
export * from '../core/interaction/tools/Hd3WheelPanTool';
export * from '../core/interaction/tools/Hd3WheelZoomTool';

// Export Vue components
export { default as VHd3Chart } from './components/VHd3Chart.vue';
export { default as VHd3Axis } from './components/VHd3Axis.vue';
export { default as VHd3Line } from './components/VHd3Line.vue';
export { default as VHd3Area } from './components/VHd3Area.vue';
export { default as VHd3Bars } from './components/VHd3Bars.vue';
export { default as VHd3Scatter } from './components/VHd3Scatter.vue';
export { default as VHd3CursorIndicator } from './components/VHd3CursorIndicator.vue';
export { default as VHd3Tooltip } from './components/VHd3Tooltip.vue';
export { default as VHd3TooltipMarkers } from './components/VHd3TooltipMarkers.vue';
export { default as VHd3Toolbox } from './components/VHd3Toolbox.vue';
export { default as VHd3AxisDomain } from './components/VHd3AxisDomain.vue';

// Export composables
export { useChart } from './composables/useChart';
export { useBus } from './composables/useBus';
export { useToolbox } from './composables/useToolbox';
export { useChartElement } from './composables/useChartElement';
