// Composable for managing toolbox state
import { reactive, onUnmounted } from 'vue';
import { Hd3Toolbox } from '../../core/interaction/Hd3Toolbox';
import type { Hd3ToolStateChangedEvent } from '../../core/interaction/Hd3Toolbox';
import { useBus } from './useBus';

export function useToolbox(tools: any[]) {
  const bus = useBus();
  const toolbox = new Hd3Toolbox();
  
  // Create reactive tool state
  const toolState = reactive(
    Object.fromEntries(tools.map((t) => [t.name, false]))
  );
  
  // Handle tool state changes
  function handleToolStateChanged({ tool, state }: Hd3ToolStateChangedEvent) {
    toolState[tool] = state;
  }
  
  // Add tools to toolbox
  for (const tool of tools) {
    toolbox.addTool(tool);
  }
  
  // Subscribe to state changes
  bus.on(toolbox.e.toolStateChanged, handleToolStateChanged);
  
  // Cleanup on unmount
  onUnmounted(() => {
    bus.off(toolbox.e.toolStateChanged, handleToolStateChanged);
  });
  
  return {
    toolbox,
    toolState
  };
}
