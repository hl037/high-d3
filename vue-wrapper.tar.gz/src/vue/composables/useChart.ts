// Composable to inject the chart context
import { inject, type InjectionKey } from 'vue';
import type { Hd3Chart } from '../../core/chart/Hd3Chart';
import { Hd3ChartSymbol } from '../index';

export function useChart(): Hd3Chart {
  const chart = inject<Hd3Chart>(Hd3ChartSymbol);
  if (!chart) {
    throw new Error('useChart must be used within a VHd3Chart component');
  }
  return chart;
}
