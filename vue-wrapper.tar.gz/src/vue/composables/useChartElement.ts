// Composable for managing chart element lifecycle
import { onMounted, onUnmounted, watch } from 'vue';
import { useChart } from './useChart';

interface ChartElement {
  addToChart(chart: any): void;
  removeFromChart?(chart: any): void;
}

export function useChartElement(
  elementFactory: () => ChartElement,
  dependencies: Array<() => any> = []
) {
  const chart = useChart();
  let element: ChartElement | null = null;
  
  function createAndAdd() {
    // Remove existing element if any
    if (element && element.removeFromChart) {
      element.removeFromChart(chart);
    }
    
    // Create new element and add to chart
    element = elementFactory();
    element.addToChart(chart);
  }
  
  onMounted(() => {
    createAndAdd();
  });
  
  onUnmounted(() => {
    if (element && element.removeFromChart) {
      element.removeFromChart(chart);
    }
  });
  
  // Watch dependencies and recreate element if needed
  dependencies.forEach(dep => {
    watch(dep, createAndAdd, { deep: true });
  });
  
  return {
    element: () => element,
    recreate: createAndAdd
  };
}
