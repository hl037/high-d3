// Composable to inject the global bus
import { inject } from 'vue';
import type { Hd3Bus } from '../../core/bus/Hd3Bus';
import { Hd3BusSymbol } from '../index';

export function useBus(): Hd3Bus {
  const bus = inject<Hd3Bus>(Hd3BusSymbol);
  if (!bus) {
    throw new Error('useBus must be used after installing Hd3Plugin');
  }
  return bus;
}
