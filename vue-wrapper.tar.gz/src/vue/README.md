# Wrapper Vue pour Hd3 Charts

## Architecture

### Plugin Vue
- `Hd3Plugin` : Initialise la bibliothèque et provide le bus global via Symbol

### Symbols d'injection
- `Hd3ChartSymbol` : Pour injecter le chart dans les enfants
- `Hd3BusSymbol` : Pour accéder au bus global
- `Hd3InteractionAreaSymbol` : Pour l'interaction area partagée

### Composants
- `VHd3Chart` : Conteneur principal avec InteractionArea automatique
- `VHd3Axis` : Axes avec v-model sur le domain
- `VHd3Line/Area/Bars/Scatter` : Séries avec v-model sur visible
- `VHd3CursorIndicator` : Curseur interactif
- `VHd3Tooltip` : Tooltip avec slot pour personnalisation
- `VHd3TooltipMarkers` : Marqueurs de tooltip
- `VHd3Toolbox` : Gestionnaire d'outils

### Composables
- `useChart()` : Injecte le chart parent
- `useBus()` : Accède au bus global
- `useToolbox()` : Gère l'état réactif des outils
- `useChartElement()` : Gère le cycle de vie des éléments

## Utilisation

```vue
<template>
  <VHd3Chart height="400">
    <VHd3Axis name="x" position="bottom" v-model:domain="xDomain" />
    <VHd3Axis name="y" position="left" :domain="[0, 100]" />
    
    <VHd3Line :series="dataSeries" v-model:visible="lineVisible">
      <template #style>
        <VHd3LineStyle color="#ff0000" :strokeWidth="2" />
      </template>
    </VHd3Line>
    
    <VHd3Tooltip>
      <template #default="{ data }">
        <div>Value: {{ data.y }}</div>
      </template>
    </VHd3Tooltip>
  </VHd3Chart>
</template>

<script setup>
import { ref } from 'vue';
import { Hd3Series } from '@/vue';

const xDomain = ref([0, 100]);
const lineVisible = ref(true);
const dataSeries = new Hd3Series({ 
  name: 'Data',
  data: [[0, 0], [50, 50], [100, 25]]
});
</script>
```

## Installation

```js
// main.js
import { createApp } from 'vue';
import { Hd3Plugin } from '@/vue';

const app = createApp(App);
app.use(Hd3Plugin);
app.mount('#app');
```

## Justifications des choix

### Provide/Inject avec Symbols
- Type-safe et évite les collisions de noms
- Pattern recommandé par Vue 3 pour la communication parent-enfant

### InteractionArea automatique
- Simplifie l'API - l'utilisateur n'a pas à l'ajouter manuellement
- Comportement par défaut le plus courant

### v-model bidirectionnel
- Pattern Vue idiomatique pour la synchronisation d'état
- Permet le contrôle externe tout en reflétant les changements internes

### Slots pour les tooltips
- Flexibilité maximale pour la personnalisation du contenu
- Pattern Vue naturel pour l'injection de contenu

### Validation des enfants
- Avertit lors de l'utilisation de composants incompatibles
- Améliore l'expérience développeur

### Gestion du cycle de vie
- Nettoyage automatique via onUnmounted
- Évite les fuites mémoire
