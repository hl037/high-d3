<template>
  <slot />
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch, computed } from 'vue';
import { Hd3Scatter } from '../../core/series/Hd3Scatter';
import type { Hd3Series } from '../../core/series/Hd3Series';
import { useChart } from '../composables/useChart';

interface Props {
  series: Hd3Series;
  axes?: [string, string];
  visible?: boolean;
  modelValue?: boolean;
  style?: {
    color?: string;
    radius?: number;
    opacity?: number;
    strokeColor?: string;
    strokeWidth?: number;
  };
}

const props = withDefaults(defineProps<Props>(), {
  axes: () => ['x', 'y'],
  visible: true
});

const emit = defineEmits<{
  'update:modelValue': [value: boolean];
  'update:visible': [value: boolean];
}>();

const chart = useChart();
let scatter: Hd3Scatter | null = null;

const computedVisible = computed(() => {
  return props.modelValue !== undefined ? props.modelValue : props.visible;
});

function createScatter() {
  // Clean up previous scatter
  if (scatter) {
    scatter.removeFromChart?.(chart);
  }
  
  // Create new scatter
  scatter = new Hd3Scatter({
    series: props.series,
    axes: props.axes,
    style: props.style
  });
  
  // Set visibility
  scatter.visible = computedVisible.value;
  
  // Add to chart
  scatter.addToChart(chart);
}

onMounted(() => {
  createScatter();
});

onUnmounted(() => {
  if (scatter) {
    scatter.removeFromChart?.(chart);
  }
});

// Watch for visibility changes
watch(computedVisible, (newVisible) => {
  if (scatter) {
    scatter.visible = newVisible;
  }
});

// Watch for style changes
watch(() => props.style, () => {
  createScatter();
}, { deep: true });

// Watch for series changes
watch(() => props.series, () => {
  createScatter();
});
</script>
