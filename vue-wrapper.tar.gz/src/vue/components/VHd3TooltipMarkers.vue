<template>
  <!-- This component doesn't render anything in Vue -->
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch } from 'vue';
import { Hd3TooltipMarkers } from '../../core/tooltip/Hd3TooltipMarkers';
import { useChart } from '../composables/useChart';

interface Props {
  visible?: boolean;
  style?: {
    radius?: number;
    strokeColor?: string;
    strokeWidth?: number;
    fillColor?: string;
  };
}

const props = withDefaults(defineProps<Props>(), {
  visible: true
});

const chart = useChart();
let markers: Hd3TooltipMarkers | null = null;

function createMarkers() {
  // Clean up previous markers
  if (markers) {
    markers.removeFromChart?.(chart);
  }
  
  // Create new markers
  markers = new Hd3TooltipMarkers({
    style: props.style
  });
  
  // Set visibility
  if ('visible' in markers) {
    markers.visible = props.visible;
  }
  
  // Add to chart
  markers.addToChart(chart);
}

onMounted(() => {
  createMarkers();
});

onUnmounted(() => {
  if (markers) {
    markers.removeFromChart?.(chart);
  }
});

// Watch for visibility changes
watch(() => props.visible, (newVisible) => {
  if (markers && 'visible' in markers) {
    markers.visible = newVisible;
  }
});

// Watch for style changes
watch(() => props.style, () => {
  createMarkers();
}, { deep: true });
</script>
