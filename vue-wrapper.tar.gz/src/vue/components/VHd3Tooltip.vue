<template>
  <Teleport v-if="tooltipData" :to="tooltipContainer">
    <div class="vhd3-tooltip" :style="tooltipStyle">
      <slot v-if="tooltipData" v-bind="tooltipData" />
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { Hd3TooltipManager } from '../../core/tooltip/Hd3TooltipManager';
import { Hd3ForeignObjectTooltip } from '../../core/tooltip/Hd3ForeignObjectTooltip';
import { useChart } from '../composables/useChart';
import { useBus } from '../composables/useBus';

interface Props {
  offset?: { x?: number; y?: number };
  style?: any;
}

const props = withDefaults(defineProps<Props>(), {
  offset: () => ({ x: 10, y: 10 })
});

const chart = useChart();
const bus = useBus();

let tooltipManager: Hd3TooltipManager | null = null;
let foTooltip: Hd3ForeignObjectTooltip | null = null;

const tooltipData = ref<any>(null);
const tooltipContainer = ref<HTMLElement | null>(null);

const tooltipStyle = computed(() => ({
  ...props.style,
  pointerEvents: 'none'
}));

function handleTooltipShow(data: any) {
  if (!foTooltip) return;
  
  const containers = foTooltip.getContainers();
  if (containers && containers.length > 0) {
    tooltipContainer.value = containers[0].container;
    tooltipData.value = {
      target: containers[0],
      data: containers[0].data,
      x: data.x,
      y: data.y,
      xSide: data.xSide || 'left',
      ySide: data.ySide || 'top'
    };
  }
}

function handleTooltipHide() {
  tooltipData.value = null;
  tooltipContainer.value = null;
}

onMounted(() => {
  // Create tooltip manager
  tooltipManager = new Hd3TooltipManager({
    offset: props.offset
  });
  
  // Create foreign object tooltip
  foTooltip = new Hd3ForeignObjectTooltip({});
  
  // Add to chart
  tooltipManager.addToChart(chart);
  foTooltip.addToChart(chart);
  
  // Subscribe to tooltip events
  bus.on(tooltipManager.e.show, handleTooltipShow);
  bus.on(tooltipManager.e.hide, handleTooltipHide);
});

onUnmounted(() => {
  if (tooltipManager) {
    bus.off(tooltipManager.e.show, handleTooltipShow);
    bus.off(tooltipManager.e.hide, handleTooltipHide);
    tooltipManager.removeFromChart?.(chart);
  }
  if (foTooltip) {
    foTooltip.removeFromChart?.(chart);
  }
});
</script>

<style scoped>
.vhd3-tooltip {
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 8px;
  border-radius: 4px;
  font-size: 12px;
  white-space: nowrap;
}
</style>
