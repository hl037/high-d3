<template>
  <!-- This component doesn't render anything in Vue -->
</template>

<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';
import type { Hd3Toolbox } from '../../core/interaction/Hd3Toolbox';
import { useChart } from '../composables/useChart';

interface Props {
  toolbox: Hd3Toolbox;
}

const props = defineProps<Props>();
const chart = useChart();

onMounted(() => {
  // Add toolbox to chart
  props.toolbox.addToChart(chart);
});

onUnmounted(() => {
  // Remove toolbox from chart if possible
  if ('removeFromChart' in props.toolbox) {
    (props.toolbox as any).removeFromChart(chart);
  }
});
</script>
