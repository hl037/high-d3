<template>
  <div ref="chartContainer" :style="{ width: '100%', height: `${height}px` }">
    <slot v-if="chartReady" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, provide, watch, useSlots } from 'vue';
import { Hd3Chart } from '../../core/chart/Hd3Chart';
import { Hd3InteractionArea } from '../../core/interaction/Hd3InteractionArea';
import { Hd3ChartSymbol, Hd3InteractionAreaSymbol } from '../index';

interface Props {
  name?: string;
  height?: number;
  margin?: {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
  };
}

const props = withDefaults(defineProps<Props>(), {
  height: 400,
  margin: () => ({ top: 20, right: 20, bottom: 40, left: 60 })
});

const chartContainer = ref<HTMLElement>();
const chartReady = ref(false);
let chart: Hd3Chart | null = null;
let interactionArea: Hd3InteractionArea | null = null;

const slots = useSlots();

// Validate that children implement addToChart
function validateChildren() {
  if (!slots.default) return;
  
  const vnodes = slots.default();
  vnodes.forEach(vnode => {
    // Check if component has addToChart capability
    const componentName = vnode.type?.name || vnode.type?.__name;
    if (componentName && !componentName.startsWith('VHd3')) {
      console.warn(`Component ${componentName} may not be compatible with VHd3Chart. Use VHd3* components.`);
    }
  });
}

onMounted(() => {
  if (!chartContainer.value) return;
  
  // Create chart
  chart = new Hd3Chart(chartContainer.value, {
    margin: props.margin
  });
  
  // Automatically add interaction area
  interactionArea = new Hd3InteractionArea();
  interactionArea.addToChart(chart);
  
  // Provide chart and interaction area to children
  provide(Hd3ChartSymbol, chart);
  provide(Hd3InteractionAreaSymbol, interactionArea);
  
  validateChildren();
  chartReady.value = true;
});

// Watch for margin changes
watch(() => props.margin, (newMargin) => {
  if (chart && newMargin) {
    chart.updateOptions({ margin: newMargin });
  }
}, { deep: true });
</script>
