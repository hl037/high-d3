<template>
  <!-- This component doesn't render anything in Vue -->
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch } from 'vue';
import { Hd3CursorIndicator } from '../../core/interaction/Hd3CursorIndicator';
import { useChart } from '../composables/useChart';

interface Props {
  showCrossX?: boolean;
  showCrossY?: boolean;
  showAxisLabels?: boolean;
  style?: {
    strokeColor?: string;
    strokeWidth?: number;
    strokeDasharray?: string;
  };
}

const props = withDefaults(defineProps<Props>(), {
  showCrossX: true,
  showCrossY: true,
  showAxisLabels: true
});

const chart = useChart();
let cursor: Hd3CursorIndicator | null = null;

function createCursor() {
  // Clean up previous cursor
  if (cursor) {
    cursor.removeFromChart?.(chart);
  }
  
  // Create new cursor
  cursor = new Hd3CursorIndicator({
    showCrossX: props.showCrossX,
    showCrossY: props.showCrossY,
    showAxisLabels: props.showAxisLabels,
    style: props.style
  });
  
  // Add to chart
  cursor.addToChart(chart);
}

onMounted(() => {
  createCursor();
});

onUnmounted(() => {
  if (cursor) {
    cursor.removeFromChart?.(chart);
  }
});

// Watch for prop changes
watch(() => [props.showCrossX, props.showCrossY, props.showAxisLabels], () => {
  if (cursor) {
    cursor.showCrossX = props.showCrossX;
    cursor.showCrossY = props.showCrossY;
    cursor.showAxisLabels = props.showAxisLabels;
  }
});

watch(() => props.style, () => {
  createCursor();
}, { deep: true });
</script>
