<template>
  <slot />
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch, computed } from 'vue';
import { Hd3Area } from '../../core/series/Hd3Area';
import type { Hd3Series } from '../../core/series/Hd3Series';
import { useChart } from '../composables/useChart';

interface Props {
  series: Hd3Series;
  axes?: [string, string];
  visible?: boolean;
  modelValue?: boolean;
  style?: {
    color?: string;
    opacity?: number;
    strokeWidth?: number;
    strokeColor?: string;
  };
}

const props = withDefaults(defineProps<Props>(), {
  axes: () => ['x', 'y'],
  visible: true
});

const emit = defineEmits<{
  'update:modelValue': [value: boolean];
  'update:visible': [value: boolean];
}>();

const chart = useChart();
let area: Hd3Area | null = null;

const computedVisible = computed(() => {
  return props.modelValue !== undefined ? props.modelValue : props.visible;
});

function createArea() {
  // Clean up previous area
  if (area) {
    area.removeFromChart?.(chart);
  }
  
  // Create new area
  area = new Hd3Area({
    series: props.series,
    axes: props.axes,
    style: props.style
  });
  
  // Set visibility
  area.visible = computedVisible.value;
  
  // Add to chart
  area.addToChart(chart);
}

onMounted(() => {
  createArea();
});

onUnmounted(() => {
  if (area) {
    area.removeFromChart?.(chart);
  }
});

// Watch for visibility changes
watch(computedVisible, (newVisible) => {
  if (area) {
    area.visible = newVisible;
  }
});

// Watch for style changes
watch(() => props.style, () => {
  createArea();
}, { deep: true });

// Watch for series changes
watch(() => props.series, () => {
  createArea();
});
</script>
