<template>
  <!-- This component doesn't render anything -->
</template>

<script setup lang="ts">
import { computed, watch, onMounted } from 'vue';
import { Hd3AxisDomain } from '../../core/axis/Hd3AxisDomain';

interface Props {
  modelValue?: [number, number];
  domain?: [number, number];
  padding?: number;
}

const props = defineProps<Props>();

const emit = defineEmits<{
  'update:modelValue': [value: [number, number]];
}>();

let axisDomain: Hd3AxisDomain | null = null;

const computedDomain = computed(() => {
  return props.modelValue || props.domain || [0, 1];
});

onMounted(() => {
  axisDomain = new Hd3AxisDomain({
    domain: computedDomain.value,
    padding: props.padding
  });
  
  // Sync domain changes back to parent
  axisDomain.on('domainChanged', (newDomain: [number, number]) => {
    emit('update:modelValue', newDomain);
  });
});

// Watch for external domain changes
watch(computedDomain, (newDomain) => {
  if (axisDomain && newDomain) {
    axisDomain.domain = newDomain;
  }
}, { deep: true });

// Expose the domain instance for parent components
defineExpose({
  axisDomain: () => axisDomain
});
</script>
