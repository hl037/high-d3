<template>
  <slot />
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch, computed } from 'vue';
import { Hd3Axis } from '../../core/axis/Hd3Axis';
import { Hd3AxisDomain } from '../../core/axis/Hd3AxisDomain';
import { useChart } from '../composables/useChart';

interface Props {
  name: string;
  position: 'top' | 'right' | 'bottom' | 'left';
  scaleType?: 'linear' | 'log' | 'time' | 'ordinal';
  domain?: [number, number] | number[];
  modelValue?: [number, number];
  gridOptions?: {
    enabled?: boolean;
    opacity?: number;
  };
  scaleOptions?: any;
}

const props = withDefaults(defineProps<Props>(), {
  scaleType: 'linear'
});

const emit = defineEmits<{
  'update:modelValue': [value: [number, number]];
  'update:domain': [value: [number, number]];
}>();

const chart = useChart();
let axis: Hd3Axis | null = null;
let axisDomain: Hd3AxisDomain | null = null;

// Compute domain from props
const computedDomain = computed(() => {
  return props.modelValue || props.domain || [0, 1];
});

function createAxis() {
  // Clean up previous axis
  if (axis) {
    axis.removeFromChart?.(chart);
  }
  
  // Create domain
  axisDomain = new Hd3AxisDomain({
    domain: computedDomain.value
  });
  
  // Create axis
  axis = new Hd3Axis({
    name: props.name,
    domain: axisDomain,
    scaleType: props.scaleType,
    position: props.position,
    scaleOptions: props.scaleOptions
  });
  
  // Apply grid options if provided
  if (props.gridOptions) {
    axis.gridOptions(props.gridOptions);
  }
  
  // Add to chart
  axis.addToChart(chart);
  
  // Set up domain sync
  axisDomain.on('domainChanged', (newDomain: [number, number]) => {
    emit('update:modelValue', newDomain);
    emit('update:domain', newDomain);
  });
}

onMounted(() => {
  createAxis();
});

onUnmounted(() => {
  if (axis) {
    axis.removeFromChart?.(chart);
  }
});

// Watch for domain changes
watch(computedDomain, (newDomain) => {
  if (axisDomain && newDomain) {
    axisDomain.domain = newDomain;
  }
}, { deep: true });

// Watch for grid options changes
watch(() => props.gridOptions, (newOptions) => {
  if (axis && newOptions) {
    axis.gridOptions(newOptions);
  }
}, { deep: true });
</script>
