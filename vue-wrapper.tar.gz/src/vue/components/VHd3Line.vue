<template>
  <slot />
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch, computed } from 'vue';
import { Hd3Line } from '../../core/series/Hd3Line';
import type { Hd3Series } from '../../core/series/Hd3Series';
import { useChart } from '../composables/useChart';

interface Props {
  series: Hd3Series;
  axes?: [string, string];
  visible?: boolean;
  modelValue?: boolean;
  style?: {
    color?: string;
    strokeWidth?: number;
    opacity?: number;
    dashArray?: string;
  };
}

const props = withDefaults(defineProps<Props>(), {
  axes: () => ['x', 'y'],
  visible: true
});

const emit = defineEmits<{
  'update:modelValue': [value: boolean];
  'update:visible': [value: boolean];
}>();

const chart = useChart();
let line: Hd3Line | null = null;

const computedVisible = computed(() => {
  return props.modelValue !== undefined ? props.modelValue : props.visible;
});

function createLine() {
  // Clean up previous line
  if (line) {
    line.removeFromChart?.(chart);
  }
  
  // Create new line
  line = new Hd3Line({
    series: props.series,
    axes: props.axes,
    style: props.style
  });
  
  // Set visibility
  line.visible = computedVisible.value;
  
  // Add to chart
  line.addToChart(chart);
}

onMounted(() => {
  createLine();
});

onUnmounted(() => {
  if (line) {
    line.removeFromChart?.(chart);
  }
});

// Watch for visibility changes
watch(computedVisible, (newVisible) => {
  if (line) {
    line.visible = newVisible;
  }
});

// Watch for style changes
watch(() => props.style, () => {
  createLine();
}, { deep: true });

// Watch for series changes
watch(() => props.series, () => {
  createLine();
});
</script>
