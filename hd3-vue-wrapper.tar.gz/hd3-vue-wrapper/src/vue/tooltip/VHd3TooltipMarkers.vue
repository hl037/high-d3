<template></template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue';
import { Hd3TooltipMarkers } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  markerStyle?: {
    radius?: number;
    strokeWidth?: number;
    strokeColor?: string;
  };
}

const props = defineProps<Props>();

const chart = useHd3Chart();
const markers = ref<Hd3TooltipMarkers>();

onMounted(() => {
  markers.value = new Hd3TooltipMarkers(props.markerStyle || {});
  markers.value.addToChart(chart);
});

onUnmounted(() => {
  markers.value?.removeFromChart?.(chart);
});
</script>
