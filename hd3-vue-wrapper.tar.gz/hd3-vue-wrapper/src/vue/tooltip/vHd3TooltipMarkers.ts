import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3TooltipMarkers } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3TooltipMarkers(options: {
  markerStyle?: {
    radius?: number;
    strokeWidth?: number;
    strokeColor?: string;
  };
} = {}) {
  return defineComponent({
    name: 'vHd3TooltipMarkers',
    setup() {
      const chart = useHd3Chart();
      const markers = ref<Hd3TooltipMarkers>();
      
      onMounted(() => {
        markers.value = new Hd3TooltipMarkers(options.markerStyle || {});
        markers.value.addToChart(chart);
      });
      
      onUnmounted(() => {
        markers.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
