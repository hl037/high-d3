<template>
  <div v-if="isActive && data" class="hd3-tooltip" :style="tooltipStyle">
    <slot :x="data.x" :y="data.y" :xSide="data.xSide" :ySide="data.ySide" :series="data.series">
      <!-- Default tooltip content -->
      <div v-for="s in data.series" :key="s.renderer.name" class="hd3-tooltip-item">
        <strong>{{ s.renderer.name }}:</strong> {{ s.y }}
      </div>
    </slot>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { Hd3TooltipManager, Hd3ForeignObjectTooltip } from '../../core';
import { useHd3Chart, useHd3Bus } from '../useHd3';

interface Props {
  offsetX?: number;
  offsetY?: number;
}

const props = withDefaults(defineProps<Props>(), {
  offsetX: 10,
  offsetY: 10
});

const chart = useHd3Chart();
const bus = useHd3Bus();
const tooltipManager = ref<Hd3TooltipManager>();
const foTooltip = ref<Hd3ForeignObjectTooltip>();
const isActive = ref(false);
const data = ref<any>(null);

const tooltipStyle = computed(() => {
  if (!data.value) return {};
  
  const { x, y, xSide, ySide } = data.value;
  let left = xSide === 'right' ? x + props.offsetX : x - props.offsetX;
  let top = ySide === 'bottom' ? y + props.offsetY : y - props.offsetY;
  
  return {
    position: 'absolute',
    left: `${left}px`,
    top: `${top}px`,
    transform: xSide === 'left' ? 'translateX(-100%)' : '',
    zIndex: 1000
  };
});

function handleShow(tooltipData: any) {
  data.value = tooltipData;
  isActive.value = true;
}

function handleHide() {
  isActive.value = false;
  data.value = null;
}

onMounted(() => {
  tooltipManager.value = new Hd3TooltipManager({ bus });
  foTooltip.value = new Hd3ForeignObjectTooltip({ bus, offsetX: props.offsetX, offsetY: props.offsetY });
  
  tooltipManager.value.addToChart(chart);
  foTooltip.value.addToChart(chart);
  
  bus.on(tooltipManager.value.e.show, handleShow);
  bus.on(tooltipManager.value.e.hide, handleHide);
});

onUnmounted(() => {
  if (tooltipManager.value) {
    bus.off(tooltipManager.value.e.show, handleShow);
    bus.off(tooltipManager.value.e.hide, handleHide);
    tooltipManager.value.removeFromChart(chart);
  }
  foTooltip.value?.removeFromChart(chart);
});
</script>

<style scoped>
.hd3-tooltip {
  background: white;
  border: 1px solid #ddd;
  padding: 8px;
  border-radius: 4px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  font-size: 12px;
  pointer-events: none;
}

.hd3-tooltip-item {
  margin: 2px 0;
}
</style>
