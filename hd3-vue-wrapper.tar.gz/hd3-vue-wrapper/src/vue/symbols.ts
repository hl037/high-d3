import type { InjectionKey } from 'vue';
import type { Hd3Bus } from '../core';
import type { Hd3Chart } from '../core';

export const BUS_KEY = Symbol('hd3:bus') as InjectionKey<Hd3Bus>;
export const CHART_KEY = Symbol('hd3:chart') as InjectionKey<Hd3Chart>;
