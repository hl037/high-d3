import { inject } from 'vue';
import { BUS_KEY, CHART_KEY } from './symbols';
import type { Hd3Bus } from '../core';
import type { Hd3Chart } from '../core';

export function useHd3Bus(): Hd3Bus {
  const bus = inject(BUS_KEY);
  if (!bus) {
    throw new Error('Hd3 bus not found. Did you install the Hd3VuePlugin?');
  }
  return bus;
}

export function useHd3Chart(): Hd3Chart {
  const chart = inject(CHART_KEY);
  if (!chart) {
    throw new Error('Chart not found. Component must be used inside VHd3Chart');
  }
  return chart;
}
