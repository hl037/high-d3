import { ref, defineComponent, h, onMounted, onUnmounted } from 'vue';
import { Hd3Toolbox } from '../core';
import { useHd3Chart } from './useHd3';

export interface ToolState {
  name: string;
  active: boolean;
}

export function useToolbox(tools: any[]) {
  const toolbox = new Hd3Toolbox(tools);
  
  const toolState = ref<ToolState[]>(
    tools.map(tool => ({
      name: tool.name,
      active: false
    }))
  );

  // Create toolbox component
  const toolboxComponent = defineComponent({
    name: 'Toolbox',
    setup() {
      const chart = useHd3Chart();
      
      onMounted(() => {
        toolbox.addToChart(chart);
      });
      
      onUnmounted(() => {
        toolbox.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });

  return {
    toolbox,
    toolState,
    toolbox: toolboxComponent
  };
}
