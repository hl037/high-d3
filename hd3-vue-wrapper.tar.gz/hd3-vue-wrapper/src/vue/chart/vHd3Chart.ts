import { defineComponent, h } from 'vue';
import VHd3Chart from './VHd3Chart.vue';

export function vHd3Chart(props: any) {
  return defineComponent({
    name: 'vHd3Chart',
    render() {
      return h(VHd3Chart, props);
    }
  });
}
