<template>
  <div ref="containerRef" class="hd3-chart">
    <slot />
    <Teleport 
      v-for="target in tooltipTargets" 
      :key="`tooltip-${target.chart.name}`"
      :to="target.container"
    >
      <slot name="tooltip" :target="target" v-bind="target.data" />
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, provide, useSlots, watchEffect } from 'vue';
import { Hd3Chart, Hd3InteractionArea, Hd3TooltipManager, Hd3ForeignObjectTooltip } from '../../core';
import { CHART_KEY } from '../symbols';
import { useHd3Bus } from '../useHd3';

interface Props {
  name?: string;
  height?: number | string;
  width?: number | string;
  margin?: {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
  };
}

const props = withDefaults(defineProps<Props>(), {
  height: 400,
  width: '100%'
});

const containerRef = ref<HTMLElement>();
const chart = ref<Hd3Chart>();
const interactionArea = ref<Hd3InteractionArea>();
const tooltipManager = ref<Hd3TooltipManager>();
const foTooltip = ref<Hd3ForeignObjectTooltip>();
const tooltipTargets = ref<any[]>([]);

const bus = useHd3Bus();
const slots = useSlots();

provide(CHART_KEY, chart);

// Validate children
function validateChildren() {
  if (!slots.default) return;
  
  const vnodes = slots.default();
  vnodes.forEach(vnode => {
    const componentName = vnode.type?.name || vnode.type?.__name;
    if (componentName && !componentName.startsWith('VHd3') && componentName !== 'Toolbox') {
      console.warn(`Component ${componentName} may not be compatible with VHd3Chart. Use VHd3* components.`);
    }
  });
}

function handleTooltipChanged() {
  if (foTooltip.value) {
    tooltipTargets.value = foTooltip.value.getContainers();
  }
}

onMounted(() => {
  if (!containerRef.value) return;
  
  chart.value = new Hd3Chart(containerRef.value, {
    margin: props.margin,
    ...(props.name && { name: props.name })
  });
  
  // Auto-add interaction area
  interactionArea.value = new Hd3InteractionArea();
  interactionArea.value.addToChart(chart.value);
  
  // Setup tooltip if slot exists
  if (slots.tooltip) {
    tooltipManager.value = new Hd3TooltipManager({ bus });
    foTooltip.value = new Hd3ForeignObjectTooltip({ bus });
    
    tooltipManager.value.addToChart(chart.value);
    foTooltip.value.addToChart(chart.value);
    
    bus.on(tooltipManager.value.e.show, handleTooltipChanged);
    bus.on(tooltipManager.value.e.hide, handleTooltipChanged);
  }
  
  validateChildren();
});

onUnmounted(() => {
  if (tooltipManager.value) {
    bus.off(tooltipManager.value.e.show, handleTooltipChanged);
    bus.off(tooltipManager.value.e.hide, handleTooltipChanged);
  }
  chart.value?.destroy?.();
});
</script>

<style scoped>
.hd3-chart {
  position: relative;
  width: v-bind('typeof props.width === "number" ? props.width + "px" : props.width');
  height: v-bind('typeof props.height === "number" ? props.height + "px" : props.height');
}
</style>
