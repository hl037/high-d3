<template>
  <slot />
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, provide, useSlots } from 'vue';
import { Hd3Line, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    strokeWidth?: number;
  };
  visible?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  visible: true
});

const emit = defineEmits<{
  'update:visible': [value: boolean];
}>();

const chart = useHd3Chart();
const line = ref<Hd3Line>();
const slots = useSlots();

// Provide line instance for VHd3LineStyle
provide('lineRenderer', line);

onMounted(() => {
  const series = props.series instanceof Hd3Series 
    ? props.series 
    : new Hd3Series(props.series);
  
  line.value = new Hd3Line({
    series,
    ...(props.axes && { axes: props.axes }),
    ...(props.style && { style: props.style })
  });
  
  line.value.addToChart(chart);
  
  // Set initial visibility
  if (!props.visible) {
    line.value.setVisible(false);
  }
});

watch(() => props.visible, (newValue) => {
  if (line.value) {
    line.value.setVisible(newValue);
  }
});

onUnmounted(() => {
  line.value?.removeFromChart?.(chart);
});
</script>
