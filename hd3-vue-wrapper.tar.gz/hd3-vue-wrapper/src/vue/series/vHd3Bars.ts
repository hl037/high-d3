import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3Bars, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3Bars(options: {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    barWidth?: number;
  };
}) {
  return defineComponent({
    name: 'vHd3Bars',
    props: {
      visible: {
        type: Boolean,
        default: true
      }
    },
    emits: ['update:visible'],
    setup(props, { emit }) {
      const chart = useHd3Chart();
      const bars = ref<Hd3Bars>();
      
      onMounted(() => {
        const series = options.series instanceof Hd3Series 
          ? options.series 
          : new Hd3Series(options.series);
        
        bars.value = new Hd3Bars({
          series,
          ...(options.axes && { axes: options.axes }),
          ...(options.style && { style: options.style })
        });
        
        bars.value.addToChart(chart);
        
        if (!props.visible) {
          bars.value.setVisible(false);
        }
      });
      
      onUnmounted(() => {
        bars.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
