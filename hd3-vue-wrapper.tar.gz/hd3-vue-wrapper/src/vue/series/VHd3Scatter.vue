<template></template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { Hd3Scatter, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    radius?: number;
  };
  visible?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  visible: true
});

const emit = defineEmits<{
  'update:visible': [value: boolean];
}>();

const chart = useHd3Chart();
const scatter = ref<Hd3Scatter>();

onMounted(() => {
  const series = props.series instanceof Hd3Series 
    ? props.series 
    : new Hd3Series(props.series);
  
  scatter.value = new Hd3Scatter({
    series,
    ...(props.axes && { axes: props.axes }),
    ...(props.style && { style: props.style })
  });
  
  scatter.value.addToChart(chart);
  
  if (!props.visible) {
    scatter.value.setVisible(false);
  }
});

watch(() => props.visible, (newValue) => {
  if (scatter.value) {
    scatter.value.setVisible(newValue);
  }
});

onUnmounted(() => {
  scatter.value?.removeFromChart?.(chart);
});
</script>
