<template></template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { Hd3Area, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    opacity?: number;
  };
  visible?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  visible: true
});

const emit = defineEmits<{
  'update:visible': [value: boolean];
}>();

const chart = useHd3Chart();
const area = ref<Hd3Area>();

onMounted(() => {
  const series = props.series instanceof Hd3Series 
    ? props.series 
    : new Hd3Series(props.series);
  
  area.value = new Hd3Area({
    series,
    ...(props.axes && { axes: props.axes }),
    ...(props.style && { style: props.style })
  });
  
  area.value.addToChart(chart);
  
  if (!props.visible) {
    area.value.setVisible(false);
  }
});

watch(() => props.visible, (newValue) => {
  if (area.value) {
    area.value.setVisible(newValue);
  }
});

onUnmounted(() => {
  area.value?.removeFromChart?.(chart);
});
</script>
