import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3Line, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3Line(options: {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    strokeWidth?: number;
  };
}) {
  return defineComponent({
    name: 'vHd3Line',
    props: {
      visible: {
        type: Boolean,
        default: true
      }
    },
    emits: ['update:visible'],
    setup(props, { emit }) {
      const chart = useHd3Chart();
      const line = ref<Hd3Line>();
      
      onMounted(() => {
        const series = options.series instanceof Hd3Series 
          ? options.series 
          : new Hd3Series(options.series);
        
        line.value = new Hd3Line({
          series,
          ...(options.axes && { axes: options.axes }),
          ...(options.style && { style: options.style })
        });
        
        line.value.addToChart(chart);
        
        if (!props.visible) {
          line.value.setVisible(false);
        }
      });
      
      onUnmounted(() => {
        line.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
