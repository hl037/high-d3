<template></template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { Hd3Bars, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    barWidth?: number;
  };
  visible?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  visible: true
});

const emit = defineEmits<{
  'update:visible': [value: boolean];
}>();

const chart = useHd3Chart();
const bars = ref<Hd3Bars>();

onMounted(() => {
  const series = props.series instanceof Hd3Series 
    ? props.series 
    : new Hd3Series(props.series);
  
  bars.value = new Hd3Bars({
    series,
    ...(props.axes && { axes: props.axes }),
    ...(props.style && { style: props.style })
  });
  
  bars.value.addToChart(chart);
  
  if (!props.visible) {
    bars.value.setVisible(false);
  }
});

watch(() => props.visible, (newValue) => {
  if (bars.value) {
    bars.value.setVisible(newValue);
  }
});

onUnmounted(() => {
  bars.value?.removeFromChart?.(chart);
});
</script>
