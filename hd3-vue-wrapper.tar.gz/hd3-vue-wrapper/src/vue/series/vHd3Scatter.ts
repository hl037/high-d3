import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3Scatter, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3Scatter(options: {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    radius?: number;
  };
}) {
  return defineComponent({
    name: 'vHd3Scatter',
    props: {
      visible: {
        type: Boolean,
        default: true
      }
    },
    emits: ['update:visible'],
    setup(props, { emit }) {
      const chart = useHd3Chart();
      const scatter = ref<Hd3Scatter>();
      
      onMounted(() => {
        const series = options.series instanceof Hd3Series 
          ? options.series 
          : new Hd3Series(options.series);
        
        scatter.value = new Hd3Scatter({
          series,
          ...(options.axes && { axes: options.axes }),
          ...(options.style && { style: options.style })
        });
        
        scatter.value.addToChart(chart);
        
        if (!props.visible) {
          scatter.value.setVisible(false);
        }
      });
      
      onUnmounted(() => {
        scatter.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
