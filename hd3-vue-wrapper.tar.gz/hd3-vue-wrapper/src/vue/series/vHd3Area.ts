import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3Area, Hd3Series } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3Area(options: {
  series: Hd3Series | { name: string; data: any[] };
  axes?: string[];
  style?: {
    color?: string;
    opacity?: number;
  };
}) {
  return defineComponent({
    name: 'vHd3Area',
    props: {
      visible: {
        type: Boolean,
        default: true
      }
    },
    emits: ['update:visible'],
    setup(props, { emit }) {
      const chart = useHd3Chart();
      const area = ref<Hd3Area>();
      
      onMounted(() => {
        const series = options.series instanceof Hd3Series 
          ? options.series 
          : new Hd3Series(options.series);
        
        area.value = new Hd3Area({
          series,
          ...(options.axes && { axes: options.axes }),
          ...(options.style && { style: options.style })
        });
        
        area.value.addToChart(chart);
        
        if (!props.visible) {
          area.value.setVisible(false);
        }
      });
      
      onUnmounted(() => {
        area.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
