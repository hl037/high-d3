<template></template>

<script setup lang="ts">
import { inject, onMounted } from 'vue';

interface Props {
  color?: string;
  strokeWidth?: number;
  strokeDasharray?: string;
  opacity?: number;
}

const props = defineProps<Props>();
const lineRenderer = inject<any>('lineRenderer');

onMounted(() => {
  if (lineRenderer?.value) {
    lineRenderer.value.setStyle({
      color: props.color,
      strokeWidth: props.strokeWidth,
      strokeDasharray: props.strokeDasharray,
      opacity: props.opacity
    });
  }
});
</script>
