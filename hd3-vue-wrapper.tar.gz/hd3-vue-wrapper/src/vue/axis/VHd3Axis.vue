<template>
  <slot />
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, watch, computed, useSlots, provide } from 'vue';
import { Hd3Axis, Hd3AxisDomain } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  name: string;
  position: 'top' | 'bottom' | 'left' | 'right';
  scaleType?: 'linear' | 'log' | 'time' | 'band' | 'point';
  domain?: Hd3AxisDomain | [number, number] | [Date, Date] | string[];
  modelValue?: [number, number] | [Date, Date] | string[];
  scaleOptions?: any;
  label?: string;
}

const props = withDefaults(defineProps<Props>(), {
  scaleType: 'linear'
});

const emit = defineEmits<{
  'update:modelValue': [value: any];
  'update:domain': [value: any];
}>();

const chart = useHd3Chart();
const axis = ref<Hd3Axis>();
const axisDomain = ref<Hd3AxisDomain>();
const slots = useSlots();

// Handle domain - either from prop or from child VHd3AxisDomain
const effectiveDomain = computed(() => {
  if (props.modelValue) return props.modelValue;
  if (props.domain instanceof Hd3AxisDomain) return props.domain;
  if (props.domain) return props.domain;
  return undefined;
});

// Provide axis for child AxisDomain
provide('axis', axis);

onMounted(() => {
  // Create domain if needed
  if (effectiveDomain.value && !(effectiveDomain.value instanceof Hd3AxisDomain)) {
    axisDomain.value = new Hd3AxisDomain({ domain: effectiveDomain.value });
  } else if (effectiveDomain.value instanceof Hd3AxisDomain) {
    axisDomain.value = effectiveDomain.value;
  }
  
  // Create axis
  axis.value = new Hd3Axis({
    name: props.name,
    domain: axisDomain.value,
    scaleType: props.scaleType,
    position: props.position,
    scaleOptions: props.scaleOptions,
    ...(props.label && { label: props.label })
  });
  
  axis.value.addToChart(chart);
});

// Watch for domain changes
watch(() => props.modelValue, (newValue) => {
  if (newValue && axisDomain.value) {
    axisDomain.value.setDomain(newValue);
    emit('update:domain', newValue);
  }
});

onUnmounted(() => {
  axis.value?.removeFromChart?.(chart);
});
</script>
