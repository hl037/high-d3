<template></template>

<script setup lang="ts">
import { inject, onMounted, watch } from 'vue';
import { Hd3AxisDomain } from '../../core';

interface Props {
  modelValue?: [number, number] | [Date, Date] | string[];
}

const props = defineProps<Props>();

const emit = defineEmits<{
  'update:modelValue': [value: any];
}>();

const axis = inject<any>('axis');
const domain = ref<Hd3AxisDomain>();

onMounted(() => {
  if (props.modelValue) {
    domain.value = new Hd3AxisDomain({ domain: props.modelValue });
    if (axis?.value) {
      axis.value.setDomain(domain.value);
    }
  }
});

watch(() => props.modelValue, (newValue) => {
  if (newValue && domain.value) {
    domain.value.setDomain(newValue);
  }
});
</script>
