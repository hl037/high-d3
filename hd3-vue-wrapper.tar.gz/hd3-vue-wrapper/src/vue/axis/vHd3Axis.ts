import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3Axis, Hd3AxisDomain } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3Axis(options: {
  name: string;
  position: 'top' | 'bottom' | 'left' | 'right';
  domain?: Hd3AxisDomain | [number, number] | [Date, Date] | string[];
  scaleType?: 'linear' | 'log' | 'time' | 'band' | 'point';
  scaleOptions?: any;
  label?: string;
}) {
  return defineComponent({
    name: options.name,
    setup() {
      const chart = useHd3Chart();
      const axis = ref<Hd3Axis>();
      
      onMounted(() => {
        let domain = options.domain;
        if (domain && !(domain instanceof Hd3AxisDomain)) {
          domain = new Hd3AxisDomain({ domain });
        }
        
        axis.value = new Hd3Axis({
          ...options,
          domain
        });
        
        axis.value.addToChart(chart);
      });
      
      onUnmounted(() => {
        axis.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
