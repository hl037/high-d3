<template></template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { Hd3CursorIndicator } from '../../core';
import { useHd3Chart } from '../useHd3';

interface Props {
  showCrossX?: boolean;
  showCrossY?: boolean;
  showAxisLabels?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  showCrossX: true,
  showCrossY: true,
  showAxisLabels: true
});

const chart = useHd3Chart();
const cursor = ref<Hd3CursorIndicator>();

onMounted(() => {
  cursor.value = new Hd3CursorIndicator({
    showCrossX: props.showCrossX,
    showCrossY: props.showCrossY,
    showAxisLabels: props.showAxisLabels
  });
  
  cursor.value.addToChart(chart);
});

// Watch for prop changes
watch(() => [props.showCrossX, props.showCrossY, props.showAxisLabels], () => {
  if (cursor.value) {
    cursor.value.setOptions({
      showCrossX: props.showCrossX,
      showCrossY: props.showCrossY,
      showAxisLabels: props.showAxisLabels
    });
  }
});

onUnmounted(() => {
  cursor.value?.removeFromChart?.(chart);
});
</script>
