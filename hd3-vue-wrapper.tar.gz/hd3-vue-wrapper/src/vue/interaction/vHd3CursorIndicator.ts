import { defineComponent, h, onMounted, onUnmounted, ref } from 'vue';
import { Hd3CursorIndicator } from '../../core';
import { useHd3Chart } from '../useHd3';

export function vHd3CursorIndicator(options: {
  showCrossX?: boolean;
  showCrossY?: boolean;
  showAxisLabels?: boolean;
} = {}) {
  return defineComponent({
    name: 'vHd3CursorIndicator',
    setup() {
      const chart = useHd3Chart();
      const cursor = ref<Hd3CursorIndicator>();
      
      onMounted(() => {
        cursor.value = new Hd3CursorIndicator({
          showCrossX: options.showCrossX ?? true,
          showCrossY: options.showCrossY ?? true,
          showAxisLabels: options.showAxisLabels ?? true
        });
        
        cursor.value.addToChart(chart);
      });
      
      onUnmounted(() => {
        cursor.value?.removeFromChart?.(chart);
      });
      
      return () => null;
    }
  });
}
