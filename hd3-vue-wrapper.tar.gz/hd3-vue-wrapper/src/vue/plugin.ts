import type { App } from 'vue';
import { getHd3GlobalBus, type Hd3Bus } from '../core';
import { BUS_KEY } from './symbols';

export interface Hd3VuePluginOptions {
  bus?: Hd3Bus;
}

export const Hd3VuePlugin = {
  install(app: App, options: Hd3VuePluginOptions = {}) {
    const bus = options.bus || getHd3GlobalBus();
    app.provide(BUS_KEY, bus);
  }
};
